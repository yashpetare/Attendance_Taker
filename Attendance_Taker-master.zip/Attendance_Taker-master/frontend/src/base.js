// export const BASE_URL = "http://localhost:5000";
export const BASE_URL = "https://attendance-taker-uhew.onrender.com";
